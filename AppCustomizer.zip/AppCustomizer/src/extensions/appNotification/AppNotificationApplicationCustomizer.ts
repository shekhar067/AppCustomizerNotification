// import { Log } from '@microsoft/sp-core-library';
// import {
//   BaseApplicationCustomizer
// } from '@microsoft/sp-application-base';
// import { Dialog } from '@microsoft/sp-dialog';

// import * as strings from 'AppNotificationApplicationCustomizerStrings';

// const LOG_SOURCE: string = 'AppNotificationApplicationCustomizer';

// /**
//  * If your command set uses the ClientSideComponentProperties JSON input,
//  * it will be deserialized into the BaseExtension.properties object.
//  * You can define an interface to describe it.
//  */
// export interface IAppNotificationApplicationCustomizerProperties {
//   // This is an example; replace with your own property
//   testMessage: string;
// }

// /** A Custom Action which can be run during execution of a Client Side Application */
// export default class AppNotificationApplicationCustomizer
//   extends BaseApplicationCustomizer<IAppNotificationApplicationCustomizerProperties> {

//   public onInit(): Promise<void> {
//     Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);

//     let message: string = this.properties.testMessage;
//     if (!message) {
//       message = '(No properties were provided.)';
//     }

//     Dialog.alert(`Hello from ${strings.Title}:\n\n${message}`).catch(() => {
//       /* handle error */
//     });

//     return Promise.resolve();
//   }
// }import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as toastr from 'toastr';

import * as strings from 'AppNotificationApplicationCustomizerStrings';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';

const LOG_SOURCE: string = 'AppNotificationApplicationCustomizer';

export interface IAppNotificationApplicationCustomizerProperties {
  listTitle: string;
  messageLimit: number;
}

export default class AppNotificationApplicationCustomizer
  extends BaseApplicationCustomizer<IAppNotificationApplicationCustomizerProperties> {
 constructor(props:IAppNotificationApplicationCustomizerProperties){
  super();
  SPComponentLoader.loadCss('https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css');
 }
  private _topPlaceholder: PlaceholderContent | undefined;
  private _listItems: any[] = [];

 
  public async onInit(): Promise<void> {
    Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);

    // Set up placeholders
    this._topPlaceholder = this.context.placeholderProvider.tryCreateContent(
      PlaceholderName.Top,
      { onDispose: this._onDispose }
    );

    if (!this._topPlaceholder) {
      // Log.error(LOG_SOURCE,err);
      return Promise.resolve();
    }

    // Get items from list
    try {
      const items = await this.getListItems();
      this._listItems = items.map(item => ({
        message: item.Title,
        category: item.Category
      }));
      Log.info(LOG_SOURCE, `Got ${this._listItems.length} items from list.`);
    } catch (error) {
      Log.error(LOG_SOURCE, error);
    }

    // Show toastr notifications
    if (this._listItems.length) {
      this._showNotification(this._listItems.pop());
    }
   
      
    return Promise.resolve();
  }

  private _onDispose(): void {
    // Clean up code
  }

  private _showNotification(item: any): void {
toastr.options.closeButton= true;
toastr.options.newestOnTop= true;
toastr.options.progressBar= true;
toastr.options.positionClass= 'toast-top-right';
toastr.options.hideDuration=10000;




debugger;
    switch (item.category) {
      case 'Success':
        toastr.success(item.message, item.category);
        break;
      case 'Warning':
        toastr.warning(item.message, item.category);
        break;
      case 'Error':
        toastr.error(item.message, item.category);
        break;
      default:
        toastr.info(item.message, item.category);
        break;
    }

    // Show next notification
    if (this._listItems.length) {
      setTimeout(() => {
        this._showNotification(this._listItems.pop());
      }, 5000);
    }
  }

  private getListItems(): Promise<any[]> {
    const listTitle = 'Notification';
    const queryUrl = `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getByTitle('${listTitle}')/items?$select=Title,Category`;

    return this.context.spHttpClient.get(queryUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error(`Failed to get list items: ${response.statusText}`);
        }
      })
      .then((data: any) => {
        return data.value;
      })
      

      .catch((error: any) => {
        Log.error(LOG_SOURCE, error);
        return [];
      });
  }
}
