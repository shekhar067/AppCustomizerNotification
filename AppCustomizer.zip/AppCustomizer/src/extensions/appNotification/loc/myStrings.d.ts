declare interface IAppNotificationApplicationCustomizerStrings {
  Title: string;
}

declare module 'AppNotificationApplicationCustomizerStrings' {
  const strings: IAppNotificationApplicationCustomizerStrings;
  export = strings;
}
