define([], function() {
  return {
    "Title": "AppNotificationApplicationCustomizer"
  }
});