import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface IAppNotificationApplicationCustomizerProperties {
    listTitle: string;
    messageLimit: number;
}
export default class AppNotificationApplicationCustomizer extends BaseApplicationCustomizer<IAppNotificationApplicationCustomizerProperties> {
    constructor(props: IAppNotificationApplicationCustomizerProperties);
    private _topPlaceholder;
    private _listItems;
    onInit(): Promise<void>;
    private _onDispose;
    private _showNotification;
    private getListItems;
}
//# sourceMappingURL=AppNotificationApplicationCustomizer.d.ts.map